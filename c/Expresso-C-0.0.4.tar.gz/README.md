# C Implementation

[⬅️ Return to Hub](https://github.com/JaehoChoi00/Expresso/blob/main/README.md)

## Code

> * [`Expresso.h`](include/expresso/Expresso.h)
> * [`Exposure.h`](include/expresso/Exposure.h)
> * [`ExposureCategory.h`](include/expresso/ExposureCategory.h)
> * [`ExposureLevel.h`](include/expresso/ExposureLevel.h)
> * [`ExposureTimeSource.h`](include/expresso/ExposureTimeSource.h)
> * [`VariableConstants.h`](include/expresso/VariableConstants.h)
> * [`Expresso.c`](src/Expresso.c)
> * [`Exposure.c`](src/Exposure.c)
> * [`ExposureCategory.c`](src/ExposureCategory.c)

## Sections

> * [`Overview`](#overview)
> * [`Installation & Build`](#installation--build)
> * [`API Fields & Styles`](#api-fields--styles)
> * [`Configuration Methods`](#configuration-methods)
> * [`Dual-Mode Evaluation Logic`](#dual-mode-evaluation-logic)
> * [`Time Sources & Runtime Timing`](#time-sources--runtime-timing)
> * [`Bridges & Pipelines`](#bridges--pipelines)
> * [`Formatting & Diagnostic Actions`](#formatting--diagnostic-actions)
> * [`Exposure Depth`](#exposure-depth)
> * [`Core API Integration`](#core-api-integration)
> * [`Thread Safety`](#thread-safety)
> * [`Design Philosophy`](#design-philosophy)

---

### [Overview](#sections)

Expresso is a lightweight exposure and diagnostic framework built around a **2D exposure filtering matrix of Category × Level**.

```text
Exposure
│
├── Category Domain Set
│   └── ExposureCategory
│       ├── VANILLA
│       ├── SYSTEMLOG
│       ├── DEBUG
│       ├── COMPONENTIAL
│       ├── LOWERLEVEL
│       ├── BITWISE
│       └── TEST
│
├── Depth Level Set
│   └── ExposureLevel
│       ├── LEVEL1
│       ├── LEVEL2
│       ├── LEVEL3
│       ├── LEVEL4
│       └── LEVEL5
│
├── Event Index Filter
│   └── globalEventCounter
│       └── minIndex <= event <= maxIndex
│
├── Identity Context
│   └── Optional component / subsystem identity
│
├── Dual-Mode Filtering Engine
│   ├── Single Level
│   │   └── Depth of Exposure Level
│   │       └── ActiveLevel >= RequiredLevel
│   │
│   └── Multiple Levels
│       └── Explicit Hand-Picked Isolation
│           └── RequiredLevel is enabled
│
├── Time Systems
│   ├── Application Time
│   │   └── ExposureTimeSource
│   │
│   ├── Absolute Timestamp
│   │   └── System Clock
│   │
│   └── Expresso Runtime Elapsed Time
│       └── Monotonic Runtime Clock
│
├── Output Bridge
│   └── function pointer
│       ├── NULL -> stdout
│       └── active -> External Consumer
│
└── Formatting / Diagnostics
    ├── Index
    ├── Identity
    ├── Category
    ├── Level
    ├── Time
    ├── Process ID (PID)
    ├── Thread ID (TID)
    ├── Error Styling
    ├── HERE Styling
    └── ANSI Formatting
```

The central design principle is:

> Expresso decides what information is exposed. It does not decide what the consuming application should do with that information.

---

### [Installation & Build](#sections)

The C implementation is designed as a native C library.

It can be built directly from source, integrated into another C project as a library, or installed as a reusable CMake package.

> * [`Requirements`](#requirements)
> * [`Build`](#build)
> * [`Distribution`](#distribution)
> * [`Run the Test Suite`](#run-the-test-suite)
> * [`Development Workflow`](#development-workflow)

#### [Requirements](#installation--build)

The C implementation requires:

* C compiler with C11 support

* Standard C library

* POSIX threads (`pthread`) for the current thread-safe runtime implementation

* CMake

On macOS, the implementation can be compiled using Clang.

On Linux, GCC or Clang can be used.

#### [Build](#installation--build)

The C implementation uses CMake to configure and build Expresso as a static library.

From the `c/` directory:

```bash
cmake -S . -B build
cmake --build build
```

After a successful build, the build directory contains:

```text
build/

├── libexpresso.a
├── ExpressoTest
├── LibraryTest
└── ThreadTest
```

The resulting `libexpresso.a` can be distributed and linked into other C projects.

The public headers are located in:

```text
include/

└── expresso/

    ├── Expresso.h
    ├── Exposure.h
    ├── ExposureCategory.h
    ├── ExposureLevel.h
    ├── ExposureTimeSource.h
    └── VariableConstants.h
```

A consuming C project requires the compiled library and the public headers:

```text
lib/

└── libexpresso.a

include/

└── expresso/

    ├── Expresso.h
    ├── Exposure.h
    ├── ExposureCategory.h
    ├── ExposureLevel.h
    ├── ExposureTimeSource.h
    └── VariableConstants.h
```

The generated library can then be linked with a C compiler:

```bash
gcc main.c \
    -Iinclude \
    -Llib \
    -lexpresso \
    -pthread \
    -o MyProgram
```

`-I` specifies the location of the Expresso headers.

`-L` specifies the location of the directory containing `libexpresso.a`.

`-lexpresso` links the Expresso static library.

`-pthread` enables the POSIX thread support required by the current C implementation.

#### [Distribution](#installation--build)

Expresso can be distributed as a self-contained C library package containing the compiled static library and public headers.

A basic distribution can have the following structure:

```text
Expresso/

├── lib/
│   └── libexpresso.a
│
└── include/
    └── expresso/
        ├── Expresso.h
        ├── Exposure.h
        ├── ExposureCategory.h
        ├── ExposureLevel.h
        ├── ExposureTimeSource.h
        └── VariableConstants.h
```

A consuming project can copy or extract this package and link Expresso directly without installing Expresso globally.

Expresso also provides CMake package configuration files for projects that use CMake.

The package can be installed locally with:

```bash
cmake --install build --prefix ./install
```

This produces an install tree containing the library, public headers, and CMake package configuration:

```text
install/

├── lib/
│   ├── libexpresso.a
│   └── cmake/
│       └── Expresso/
│           ├── ExpressoConfig.cmake
│           ├── ExpressoConfigVersion.cmake
│           └── ExpressoTargets.cmake
│
└── include/
    └── expresso/
        ├── Expresso.h
        ├── Exposure.h
        ├── ExposureCategory.h
        ├── ExposureLevel.h
        ├── ExposureTimeSource.h
        └── VariableConstants.h
```

A CMake project can then locate the installed Expresso package with:

```cmake
find_package(Expresso REQUIRED)

target_link_libraries(MyProgram
    PRIVATE
        Expresso::expresso
)
```

When the package is installed in a custom location, the consuming project can provide that location through `CMAKE_PREFIX_PATH`:

```bash
cmake -S . -B build \
    -DCMAKE_PREFIX_PATH=/path/to/Expresso/install
```

This allows Expresso to be distributed as a reusable CMake package without requiring the consuming project to copy Expresso's source files into its own project.

#### [Run the Test Suite](#installation--build)

Expresso includes three C test programs:

* [ExpressoTest](/c/test/ExpressoTest.c) — verifies core Expresso behavior
* [LibraryTest](/c/test/LibraryTest.c) — verifies that Expresso can be consumed as a compiled static library
* [ThreadTest](/c/test/ThreadTest.c) — verifies concurrent event generation and event-counter behavior

The tests are built automatically by CMake.

After building:

```bash
cmake --build build
```

Run all registered tests with CTest:

```bash
ctest --test-dir build
```

A successful run reports:

```text
    Start 1: ExpressoTest
1/3 Test #1: ExpressoTest .....................   Passed    0.00 sec

    Start 2: LibraryTest
2/3 Test #2: LibraryTest ......................   Passed    0.00 sec

    Start 3: ThreadTest
3/3 Test #3: ThreadTest .......................   Passed    0.00 sec

100% tests passed, 0 tests failed out of 3
```

The test suite covers core Expresso behavior, including:

* Exposure creation
* Identity handling
* Category filtering
* Level filtering
* Multiple category selection
* Dynamic custom categories
* Lazy exposure evaluation
* Formatted exposure
* Raw message preservation
* Event indexing
* Index filtering
* Newline handling
* Line-break formatting
* Error reporting
* Lazy error reporting
* Error styling
* HERE execution markers
* HERE styling
* Tag visibility
* Diagnostic tags
* Direct output
* External bridges
* Event counter behavior
* Reset behavior
* Process ID (PID) tag
* Thread ID (TID) tag
* Thread ID filtering and filter clearing
* PID/TID reset behavior

***To run only the thread test:***

```bash
ctest --test-dir build -R ThreadTest
```

***A successful run reports:***

```text
    Start 3: ThreadTest

1/1 Test #3: ThreadTest .......................   Passed    0.00 sec

100% tests passed, 0 tests failed out of 1

Total Test time (real) =   0.01 sec
```

#### [Development Workflow](#installation--build)

The normal development cycle is:

```text
Modify Source
     │
     ▼

Configure CMake
     │
     ▼

Build Library and Tests
     │
     ▼

Run CTest
     │
     ▼

Verify Behavior
     │
     ▼

Install or Distribute

```

From the `c/` directory:

```bash
cmake -S . -B build
cmake --build build
ctest --test-dir build

# To run a specific test directly:

./build/ExpressoTest

./build/LibraryTest

./build/ThreadTest

# To perform a clean rebuild:

rm -rf build

cmake -S . -B build

cmake --build build

ctest --test-dir build

# To install Expresso locally:

cmake --install build --prefix ./install
```

---

### [API Fields & Styles](#sections)

| Text Formatting Type    | API Variable Alias         | Source                |
| ----------------------- | -------------------------- | --------------------- |
| Reset Code              | `RESET`                    | `VariableConstants.h` |
| Font Adjustments        | `BOLD`, `DIM`, `UNDERLINE` | `VariableConstants.h` |
| Line Controls           | `LINEFEED`                 | `VariableConstants.h` |
| Text Foreground Palette | `FG_BLACK` to `FG_WHITE`   | `VariableConstants.h` |
| Background Palette      | `BG_BLACK` to `BG_WHITE`   | `VariableConstants.h` |

The C implementation exposes these values as C macros rather than Java static fields.

For example:

```c
printf("%s%sREADY%s\n", BOLD, FG_GREEN, RESET);
```

ANSI formatting is optional and is simply part of the emitted text.

Expresso does not require consumers to use its formatting constants.

---

### [Configuration Methods](#sections)

> * [Level Filtering](#level-filtering)
> * [Category Filtering](#category-filtering)
> * [Tag Visibility](#tag-visibility)
> * [Event Index Filtering](#event-index-filtering)
> * [Thread ID Filtering](#thread-id-filtering)
> * [Reset](#reset)
> * [Diagnositc Styling](#diagnostic-styling)

#### [Level Filtering](#configuration-methods)

```c
void setLevel(ExposureLevel level);

void setLevels(ExposureLevel level, ...);
```

`setLevel()` activates Cascading Mode.

`setLevels()` activates Explicit Mode when multiple levels are supplied.

An empty level configuration prevents exposure events from being emitted.

The default level after `reset()` is:

```text
LEVEL1
```

#### [Category Filtering](#configuration-methods)

```c
void setCategory(ExposureCategory category);

void setCategories(ExposureCategory category, ...);

void enableCategory(ExposureCategory category);

void disableCategory(ExposureCategory category);

void clearAllCategories();
```

An empty category set acts as an unrestricted category filter.

C also supports custom categories:

```c
CUSTOM_CATEGORY(PHYSICS, "PHYSICS");
```

Custom categories are identified by their category name.

For example:

```c
CUSTOM_CATEGORY(PHYSICS, "PHYSICS");

setCategory(PHYSICS);
```

produces:

```text
[PHYSICS]
```

Category names therefore allow applications to define their own domain-specific exposure categories without modifying Expresso's built-in category enumeration.

---

#### [Event Index Filtering](#configuration-methods)

```c
void setIndexRange(long long start, long long end);

void setIndexRangeMax(long long end);

void setSingleIndex(long long targetIndex);

void clearIndexFilter();

void resetEventCounter();

long long getCurrentEventCount();
```

The event index represents Expresso exposure events and is independent of any event, frame, or lifecycle counter maintained by the consuming application.

The global event counter allows specific sections of an execution trace to be isolated without modifying the original exposure statements.

The event index is allocated after category and level filtering and before the index-range filter is applied.

Therefore:

```text
Category / Level Filter
        │
        ▼
Event Index Allocated
        │
        ▼
Index Range Filter
        │
        ▼
Output
```

An exposure rejected by category or level does not consume an event index.

An exposure that receives an event index but falls outside the configured index range still advances the event counter.

---


#### [Thread ID Filtering](#configuration-methods)

```c
#include <stdint.h>
#include <stddef.h>

uint64_t tids[] = {1234, 5678};

setTIDFilter(tids, 2);

setTIDFilter(tids, 1);

setTIDFilter(NULL, 0);

clearTIDFilter();
```

`setTIDFilter()` restricts exposure events to the specified native thread IDs (TIDs).

- `setTIDFilter(tids, 2)` allows events from either thread ID in the array.
- `setTIDFilter(tids, 1)` allows events from the first thread ID in the array.
- `setTIDFilter(NULL, 0)` creates an empty allowlist, preventing events from every thread from being emitted.
- `clearTIDFilter()` removes the filter, allowing events from any thread that passes the other active filters.

The function accepts a pointer to an array of `uint64_t` thread IDs and the number of IDs in that array.

> [!Note]
>
> Thread ID filtering and TID tag visibility are independent.
>
> `setTIDFilter()` controls which events can be emitted.
>
> `enableTIDTag(true)` controls whether the TID appears in the output.
>
> Thread ID filtering is disabled by default. When no TID filter is active, events from any thread may be emitted if they pass the other active filters.

---

#### [Reset](#configuration-methods)

```c
void reset();
```

`reset()` restores the core Expresso runtime state, including:

* Event counter
* Index filtering
* Category filtering
* Level filtering
* Tag configuration
* Timing configuration
* External bridge configuration

Custom error and HERE styles are preserved by reset.

#### [Diagnostic Styling](#configuration-methods)

```c
void setErrorStyle(const char *color, const char *prefix);

void resetErrorStyle(void);

void setHereStyle(const char *color, const char *header);

void resetHereStyle(void);

void enableDiagnosticTags(bool enable);
```

Diagnostic tags are disabled by default.

When enabled, unrestricted diagnostic events such as `error()` and `hereAnnounce()` can inherit the active timing metadata.

---

### [Dual-Mode Evaluation Logic](#sections)

> * [Single-Level / Casceading Mode](#single-level--cascading-mode)
> * [Multi-Level / Explicit Mode](#multi-level--explicit-mode)

Expresso uses the number of enabled exposure levels to determine its filtering mode.

```c
bool isExposed(ExposureCategory category, ExposureLevel requiredLevel);
```

The evaluation process is:

```text
Category valid?
     │
     ▼
Category enabled?
     │
     ▼
Level configuration valid?
     │
     ├── One level
     │      │
     │      ▼
     │   RequiredLevel <= ActiveLevel
     │
     └── Multiple levels
            │
            ▼
       RequiredLevel explicitly enabled
```

#### [Single-Level / Cascading Mode](#dual-mode-evaluation-logic)

```c
setLevel(LEVEL3);
```

Produces:

```text
LEVEL1 -> exposed
LEVEL2 -> exposed
LEVEL3 -> exposed
LEVEL4 -> hidden
LEVEL5 -> hidden
```

The active level defines the maximum exposure depth.

This is the default hierarchical interpretation of the five exposure levels.

#### [Multi-Level / Explicit Mode](#dual-mode-evaluation-logic)

```c
setLevels(LEVEL1, LEVEL5, END_LEVEL);
```

Produces:

```text
LEVEL1 -> exposed
LEVEL2 -> hidden
LEVEL3 -> hidden
LEVEL4 -> hidden
LEVEL5 -> exposed
```

This allows non-contiguous exposure selection.

The distinction is:

```text
setLevel()
    = "Expose up to this depth."

setLevels()
    = "Expose exactly these selected depths."
```

---

### [Time Sources & Runtime Timing](#sections)

> * [`Application Time`](#application-time)
> * [`Absolute Timestamp`](#absolute-timestamp)
> * [`Expresso Runtime Elapsed Time`](#expresso-runtime-elapsed-time)

Expresso separates three concepts of time.

```text
Time
│
├── Application Time
│   └── Supplied by the consuming application
│       └── ExposureTimeSource
│
├── Absolute Timestamp
│   └── System clock
│
└── Expresso Runtime Elapsed Time
    └── Monotonic runtime clock
```

#### [Application Time](#time-sources--runtime-timing)

Applications can provide their own concept of time:

```c
void setTimeSource(ExposureTimeSource source);

void enableApplicationTime(bool enable);
```

`ExposureTimeSource` is a function pointer:

```c
typedef const char *(*ExposureTimeSource)(void);
```

The application owns the meaning of the returned string.

For example, a game could expose:

```text
DAY 142 14:32:08
```

A simulation could expose:

```text
T+0042.871s
```

A replay system could expose:

```text
FRAME 183920
```

Expresso simply displays the value supplied by the source.

This allows Expresso to integrate with systems whose internal notion of time is completely different from real-world time.

#### [Absolute Timestamp](#time-sources--runtime-timing)

```c
enableTimestamp(true);
```

The C implementation obtains the current system date/time and formats it for diagnostic output.

An example is:

```text
[2026-09-24 01:44:49.099]
```

This provides a human-readable real-world date and time.

#### [Expresso Runtime Elapsed Time](#time-sources--runtime-timing)

```c
enableElapsedTime(true);
```

The elapsed time is measured relative to Expresso's runtime initialization.

The C implementation uses a monotonic runtime clock so that elapsed time is not dependent on changes to the system wall clock.

Example:

```text
[0.001s]
```

---
### [Bridges & Pipelines](#sections)

```c
void setBridge(void (*outsideSystem)(const char *));
void setBridges(void (**bridges)(const char *), size_t count);
void addBridge(void (*bridge)(const char *));
bool removeBridge(void (*bridge)(const char *));
void clearBridges(void);
```

The bridge allows Expresso output to be routed into one or more external systems.

A bridge receives the **already constructed output string** through a function pointer:

```c
void bridge(const char *text) {
    printf("[BRIDGE] %s", text);
}

setBridge(bridge);
```

#### [Multiple Bridges](#bridges--pipelines)

Expresso supports routing the same output to multiple destinations simultaneously.

```c
void (*bridges[])(const char *) = {
    terminalBridge,
    uiBridge,
    fileBridge
};

setBridges(bridges, 3);
```

Each registered bridge receives the same formatted output string.

**Bridge management methods:**

```c
setBridge(bridge);                // Replace all bridges with one
setBridges(bridges, count);       // Replace all bridges with several
addBridge(bridge);                // Add a destination
removeBridge(bridge);             // Remove a destination
clearBridges();                   // Remove all destinations
```

The C implementation supports up to 16 registered bridges. Adding a bridge beyond that capacity does not increase the capacity.

When no bridges are registered, Expresso falls back to `stdout`.

Possible destinations include:

```text
Terminal
File
UI
Game Console
Network Stream
Custom Logger
Database
```

The bridge does not need to understand Expresso's filtering logic. It receives the resulting output after Expresso has applied its exposure filtering, index-range checks, metadata, and message formatting.

#### [Routing Pipeline](#bridges--pipelines)

```text
[Exposure Invoked]
             │
             ▼
    Is Category & Level Exposed?
             │
       ┌─────┴──────┐
      No           Yes
       │            │
       ▼            ▼
    [Abort]   Does TID Pass Filter?
                    │
              ┌─────┴─────┐
             No          Yes
              │           │
              ▼           ▼
           [Abort]  Increment Event Index
                          │
                          ▼
                   Check Index Range
                          │
                   ┌──────┴──────┐
                Outside        Inside
                   │              │
                   ▼              ▼
                [Abort]    Append Metadata
                                  │
                                  ▼
                           Format Message
                                  │
                                  ▼
                          Are Bridges Active?
                                  │
                            ┌─────┴─────┐
                           Yes          No
                            │           │
                            ▼           ▼
                     Dispatch to All  print()
                     Registered Bridges
                            │
                            ▼
                       [Complete]
```

Expresso determines what information becomes visible. The consuming application determines where that output is delivered and what happens to it.

---

### [Formatting & Diagnostic Actions](#sections)

> * [Structured Exposure](#structured-exposure)
> * [Structured Formatting](#structural-formatting)
> * [Unrestricted Error Reporting](#unrestricted-error-reporting)
> * [Execution Markers](#execution-markers)

#### [Structured Exposure](#formatting--diagnostic-actions)

The primary low-level output function is:

```c
void expressoPrintf(
    const char *identity,
    ExposureCategory category,
    ExposureLevel requiredLevel,
    const char *format,
    ...
);
```

It combines:

* Identity
* Category
* Level
* Filtering
* Event indexing
* Metadata
* Formatting
* Output routing

The `Exposure` interface normally provides the more convenient application-facing API.

#### [Structural Formatting](#formatting--diagnostic-actions)

```c
void nl(Exposure *exposure, ExposureCategory category, ExposureLevel requiredLevel);

void lbr(Exposure *exposure, ExposureCategory category, ExposureLevel requiredLevel);
```

`nl()` emits an additional blank line.

`lbr()` produces a visual line break:

```text
--------------------------------
```

These helpers are deliberately separate from normal exposure messages.

An ordinary exposure message preserves the application's supplied text exactly.

Therefore:

```c
l1(&exposure, EXPOSURE_TEST, "Message");
```

does not automatically append a newline.

If a newline is required, the application explicitly supplies:

```c
l1(&exposure, EXPOSURE_TEST, "Message\n");
```

This allows exposure output to represent arbitrary text rather than forcing every exposure event to become a line.

#### [Unrestricted Error Reporting](#formatting--diagnostic-actions)

```c
void error(const char *format, ...);
```

`error()` bypasses the normal exposure matrix.

It is intended for diagnostic failures that should be reported regardless of the active category and level filters.

Example:

```c
error("Invalid value: %d\n", value);
```

Through the `Exposure` interface:

```c
err(&exposure, "Something went wrong\n");
```

Unlike normal exposure events, errors do not require an `ExposureCategory` or `ExposureLevel`.

#### [Lazy Error Reporting](#formatting--diagnostic-actions)

```c
void errLazy(Exposure *exposure, const char *(*message)(void));
```

A lazy error callback allows the error message to be generated only when it is actually required.

The callback returns the final diagnostic string.

#### [Execution Markers](#formatting--diagnostic-actions)

```c
void here(Exposure *exposure);

void hereLabel(Exposure *exposure, const char *label);

void hereCustom(
    Exposure *exposure,
    const char *customColor,
    const char *customHeader,
    const char *label
);
```

These provide high-visibility execution markers for identifying code paths.

Example:

```c
here(&exposure);
```

or:

```c
hereLabel(&exposure, "Reached renderer initialization");
```

A customized marker can be produced with:

```c
hereCustom(
    &exposure,
    BOLD FG_GREEN,
    "--> [RENDERER CHECKPOINT]",
    "Renderer initialized"
);
```

---

### [Exposure Depth](#sections)

> * [Shorthand Levels](#shorthand-levels)
> * [Generic Exposure](#generic-exposure)
> * [Lazy Exposure](#lazy-exposure)
> * [Execution Helpers](#execution-helpers)

`Exposure` is the instance-bound developer-facing interface for `Expresso`.

```c
Exposure exposure = createWithIdentity("Renderer");
```

The identity is automatically attached to emitted exposure events.

This allows an application component to maintain its own exposure context without repeatedly supplying its identity to the underlying `Expresso` API.

For example:

```c
l1(&exposure, EXPOSURE_TEST, "Renderer initialized\n");
```

produces:

```text
[#1] [Renderer] [TEST] [LEVEL1] Renderer initialized
```

#### [Shorthand Levels](#exposure-depth)

```c
l1(&exposure, category, "...");

l2(&exposure, category, "...");

l3(&exposure, category, "...");

l4(&exposure, category, "...");

l5(&exposure, category, "...");
```

Each shorthand function represents a specific `ExposureLevel`.

Conceptually:

```text
l1() -> LEVEL1
l2() -> LEVEL2
l3() -> LEVEL3
l4() -> LEVEL4
l5() -> LEVEL5
```

#### [Generic Exposure](#exposure-depth)

```c
expose(
    &exposure,
    category,
    level,
    "..."
);
```

The generic method allows the required exposure level to be selected dynamically.

For example:

```c
expose(
    &exposure,
    EXPOSURE_DEBUG,
    LEVEL3,
    "Intermediate state: %d\n",
    value
);
```

#### [Lazy Exposure](#exposure-depth)

```c
void exposeLazy(
    Exposure *exposure,
    ExposureCategory category,
    ExposureLevel level,
    const char *(*message)(void)
);
```

The callback is evaluated only when the category and level pass the active exposure filter.

This allows expensive diagnostic calculations to remain lazy when their exposure is disabled.

For example:

```c
const char *buildDiagnostic(void) {
    return "Expensive diagnostic result\n";
}

exposeLazy(
    &exposure,
    EXPOSURE_DEBUG,
    LEVEL5,
    buildDiagnostic
);
```

This avoids performing the diagnostic calculation when the exposure is not visible.

#### [Execution Helpers](#exposure-depth)

```c
enabled(&exposure, category, level);

nl(&exposure, category, level);

lbr(&exposure, category, level);

err(&exposure, "Something went wrong\n");

errLazy(&exposure, buildDiagnostic);

here(&exposure);

hereLabel(&exposure, "Custom label");
```

These helpers provide component-local access to common Expresso operations while automatically retaining the `Exposure` identity.

---

### [Core API Integration](#sections)

> * [Example](#example)
> * [Example Output](#example-output)

#### [Example](#core-api-integration)

```c
#include <stdio.h>
#include <string.h>

#include "expresso/Expresso.h"
#include "expresso/Exposure.h"
#include "expresso/ExposureCategory.h"
#include "expresso/VariableConstants.h"

static void testBridge(const char *rawText) {
    if (rawText == NULL) {
        return;
    }

    printf("[BRIDGE PIPELINE LOG]: %s", rawText);
}

int main(void) {
    Exposure alu = createWithIdentity("ALU");

    reset();

    setCategories(
        EXPOSURE_COMPONENTIAL,
        EXPOSURE_LOWERLEVEL,
        (ExposureCategory){NONE, NULL}
    );

    setLevels(
        LEVEL1,
        LEVEL5,
        (ExposureLevel)0
    );

    enableTimestamp(true);
    enableElapsedTime(true);
    enablePIDTag(true);
    enableTIDTag(true);

    setBridge(testBridge);

    l1(&alu, EXPOSURE_COMPONENTIAL, BOLD "ALU Unit Initialized -> " RESET FG_GREEN "READY" RESET "\n");

    l3(&alu, EXPOSURE_COMPONENTIAL, "Intermediate Bus Clock: 400MHz\n");

    l5(&alu, EXPOSURE_LOWERLEVEL, "NAND Gate Transistor Logic Validated.\n");

    lbr(&alu, EXPOSURE_COMPONENTIAL, LEVEL1);

    here(&alu);

    hereLabel(&alu, "Reached ALU validation stage");

    err(&alu, "Execution failed during register calculation [%s]", "DIV_ZERO");

    reset();

    return 0;
}
```

Because Explicit Mode is active, only `LEVEL1` and `LEVEL5` exposures are emitted.

The `LEVEL3` exposure is intentionally suppressed.

The resulting flow is:

```text
ALU
 │
 ├── COMPONENTIAL / LEVEL1 → exposed
 │
 ├── COMPONENTIAL / LEVEL3 → hidden
 │
 ├── LOWERLEVEL / LEVEL5 → exposed
 │
 ├── LINE BREAK
 │
 ├── HERE
 │
 ├── HERE label
 │
 └── ERROR
```

#### [Example Output](#core-api-integration)

```text
[BRIDGE PIPELINE LOG]: [2026-10-14 12:23:41.671] [0.000s] [#1] [PID:45352] [TID:407671422] [ALU] [COMPONENTIAL] [LEVEL1] ALU Unit Initialized -> READY
[BRIDGE PIPELINE LOG]: [2026-10-14 12:23:41.671] [0.000s] [#2] [PID:45352] [TID:407671422] [ALU] [LOWERLEVEL] [LEVEL5] NAND Gate Transistor Logic Validated.
[BRIDGE PIPELINE LOG]: 
--------------------------------
[BRIDGE PIPELINE LOG]: --> [EXPRESSO REPORT HERE] [ALU]
[BRIDGE PIPELINE LOG]: --> [EXPRESSO REPORT HERE] [ALU]: Reached ALU validation stage
[BRIDGE PIPELINE LOG]: [ERROR]: [ALU] Execution failed during register calculation [DIV_ZERO]
```

---

### [Thread Safety](#sections)

The C implementation uses C11 atomics and POSIX synchronization primitives for shared runtime state.

The global event counter is maintained using an atomic integer:

```c
static atomic_llong globalEventCounter;
```

Event allocation therefore remains atomic when multiple threads generate exposure events concurrently.

Shared runtime configuration is protected using:

```c
static pthread_mutex_t stateMutex;
```

The implementation also uses:

```c
pthread_once_t
```

to initialize the runtime start reference exactly once.

The current implementation therefore separates synchronization responsibilities:

```text
Global Event Counter
        │
        └── atomic operation

Runtime Configuration
        │
        └── mutex

Runtime Initialization
        │
        └── pthread_once
```

The included `ThreadTest` verifies concurrent event generation.

For example:

```text
4 threads
×
100 exposures
=
400 exposure events
```

The expected and actual event counts are compared after all threads have joined.

The thread test demonstrates the thread-safe behavior of the event counter under concurrent exposure generation.

It does not imply that every possible external output consumer is automatically thread-safe. Applications providing their own bridge remain responsible for the thread-safety requirements of that external system.

---

## [Design Philosophy](#sections)

Expresso is divided into separate responsibilities:

```text
                    ┌──────────────────────┐
                    │      APPLICATION     │
                    │                      │
                    │  Game / Simulation / │
                    │  Engine / Tool / App │
                    └──────────┬───────────┘
                               │
                        Application Time
                               │
                               ▼
                    ┌──────────────────────┐
                    │  ExposureTimeSource  │
                    └──────────┬───────────┘
                               │
                               ▼
    ┌───────────────────────────────────────────────────────┐
    │                       EXPRESSO                        │
    │                                                       │
    │  Category ──┐                                         │
    │  Level ─────┤                                         │
    │  Index ─────┤                                         │
    │  Identity ──┤──> Exposure Evaluation ──> Formatting   │
    │  PID ───────┤                                         │
    │  TID ───────┤                                         │
    │  Time ──────┘                                         │
    │                                                       │
    └──────────────────────────┬────────────────────────────┘
                               │
                               ▼
                        Consumer<String>
                               │
                  ┌────────────┼────────────┐
                  ▼            ▼            ▼
                  UI          File       Console
```

The framework therefore provides **visibility without ownership**.

The application owns its state.

The application owns its concept of time.

Expresso decides **what becomes visible**, how it is tagged, and where the resulting exposure stream is routed. 

It does not decide what the consuming application should do with that information.

[:arrow_up: Return to Top](#c-implementation)
